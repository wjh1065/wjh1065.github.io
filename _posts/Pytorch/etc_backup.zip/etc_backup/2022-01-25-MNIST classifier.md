---
title: "Pytorch 논문 구현 [UNet]"  
categories:
 - Pytorch
tags:
 - study
 - python
---

Pytorch Practice

## UNet

2022-01-24

본 포스팅은 [한요섭](https://www.youtube.com/channel/UCpujNlw4SUpgTU5rrDXH0Jw)님의 YOUTUBE 실습 영상을 기반으로 한 스터디임을 알린다!

---

